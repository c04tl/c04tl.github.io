# Login de laboratorio

Desde PowerShell, dentro de la carpeta del laboratorio, ejecuta:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe app.py
```

Abre [el formulario local](http://127.0.0.1:5000) e inicia sesión con
`root` y `tequieromucho`. También puedes ingresar una contraseña incorrecta
para comprobar que el formulario rechaza el acceso.

El servidor escucha en la interfaz local. Al iniciar, crea `lab.sqlite3`
si hace falta y registra la cuenta de demostración. La contraseña se guarda
deliberadamente en texto plano para el ejercicio.
