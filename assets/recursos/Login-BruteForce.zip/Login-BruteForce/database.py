import sqlite3
from contextlib import closing


def initialize_database(database_path):
    """Crea la tabla y registra la cuenta de prueba si hace falta."""
    with closing(sqlite3.connect(database_path)) as connection:
        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS users (
                username TEXT PRIMARY KEY NOT NULL,
                password TEXT NOT NULL
            )
            """
        )

        # El laboratorio guarda la contraseña de demostración en texto plano.
        # Si la cuenta ya existe, SQLite conserva sus datos.
        connection.execute(
            """
            INSERT INTO users (username, password)
            VALUES (?, ?)
            ON CONFLICT(username) DO NOTHING
            """,
            ("root", "tequieromucho"),
        )
        connection.commit()


def credentials_match(database_path, username, password):
    """Comprueba si SQLite tiene una fila con ambas credenciales."""
    with closing(sqlite3.connect(database_path)) as connection:
        # Los signos ? indican dónde SQLite vincula los valores del formulario.
        cursor = connection.execute(
            """
            SELECT 1
            FROM users
            WHERE username = ? AND password = ?
            """,
            (username, password),
        )
        return cursor.fetchone() is not None
