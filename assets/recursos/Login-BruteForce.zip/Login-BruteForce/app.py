import secrets
from pathlib import Path

from flask import Flask, redirect, render_template, request, session, url_for

from database import credentials_match, initialize_database


def create_app(database_path=None):
    """Configura Flask, prepara SQLite y registra las rutas del laboratorio."""
    app = Flask(__name__)

    # Flask usa esta clave para firmar la cookie de sesión.
    app.config.update(
        SECRET_KEY=secrets.token_hex(32),
        SESSION_COOKIE_SAMESITE="Lax",
    )
    if database_path is None:
        database_path = Path(__file__).with_name("lab.sqlite3")
    initialize_database(database_path)

    @app.get("/")
    def login():
        """Muestra el formulario o el saludo según la sesión actual."""
        username = session.get("username")
        return render_template("login.html", username=username)

    @app.post("/")
    def submit_login():
        """Valida los datos enviados desde el formulario."""
        username = request.form.get("username", "")
        password = request.form.get("password", "")

        if not credentials_match(database_path, username, password):
            error_message = "Usuario o contraseña incorrectos."
            return render_template("login.html", error=error_message), 302

        # Guarda solo el nombre de usuario y vuelve a la página principal.
        session.clear()
        session["username"] = username
        return redirect(url_for("login"))

    @app.post("/logout")
    def logout():
        """Borra la sesión y vuelve al formulario."""
        session.clear()
        return redirect(url_for("login"))

    return app


if __name__ == "__main__":
    # El servidor de desarrollo escucha en la interfaz local.
    create_app().run(host="127.0.0.1", port=5000)
